import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Frame2 extends JFrame {
	String[] tags = {"Rank", "MaxBlockSize", "MaxStride", "MaxHPlanes", "NoTests", "DType", "GenHslab", "Verbose", "Modify"};
	String[] labels = {"Rank", "BlockSize", "Stride", "Max Hyperplanes", "No of Tests", "Datatype", "Generate Hyperslab", "Verbose", "Modify"};
	String[] help = {"Rank of the dataset", "Size of a block (if blocks are present, else field should be empty)", "Size of a stride (if striding is used, else field should be empty)",
		"Determines the Complexity of the hyperslabs, the larger the number of hyperplanes the more complex the hyperslab is",
		"Determines the number of tests that would be run",
		"Data type of the data",
		"Determines whether a new set of hyperslabs would be generated or an old set used",
		"Determines the level of output provided by the program",
		"If this bit is set, then the program would run with one dataset, then modify the datasets and read again.",
		"This is the original dimension of the file",
		"This is the dimension of the chunk that is to be stored contiguously",
		"This is the dimension of the extended dataset",
		"The details of the File",
		"If input is selected then the file is not created but read, if output is selected the file is created.",
		"The name of the file (for reading or writing)",
		"If the flag is set to 1 the filter would compulsarily be used, else it would be optional",
		"The compression level parameter for the gzip compression",
		"The options mask parameter of szip compression",
		"The Pixels per block parameter of szip compression"};
		String[] options = {"Yes", "No"};
		String[] file_options = {"Input", "Output"};
		String[] data_types = {"byte", "short", "int", "llint", "float", "double"};
		String[] dims = {"Dimensions", "Chunk Dimensions", "Extended Dimensions"};
		JTextField[] fields = new JTextField[5];
		JButton[] jbuttons = new JButton[9];
		JComboBox[] cboxs = new JComboBox[4];
		String[] filter;
		String rank, extend, chunk;
		JButton[] filels = new JButton[3];
		JTextField f_name = new JTextField();
		JComboBox ftype = new JComboBox(file_options);
		JTextField[][] dimensions;
		JLabel[][] Dimensions;
		JTextField[][] filter_params;
		String[] options_masks = {"Entropy Coding", "NN Coding"};
		JComboBox options_mask = new JComboBox(options_masks);

		int _rank;
		int max_y = 0;

		public Frame2(String rank, String[] filters, String chunk, String extend) {
			try {
				this.rank = rank;
				this.filter = filters;
				this.extend = extend;
				this.chunk = chunk;
				_rank = Integer.parseInt(rank);
				dimensions = new JTextField[3][_rank];
				Dimensions = new JLabel[3][_rank];
				initialize();
				jbInit();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}

		private void initialize() {
			for (int i = 0; i < 9; i++) {
				jbuttons[i] = new JButton(labels[i]);
				jbuttons[i].setActionCommand(String.valueOf(i));
				jbuttons[i].addActionListener(new Frame2_gen_actionAdapter(this));
				if (i < 5)
					if (labels[i].equals("Rank")) {
						fields[i] = new JTextField(rank);
						fields[i].setEditable(false);
					}
					else
						fields[i] = new JTextField();
				else if (i == 5)
					cboxs[0] = new JComboBox(data_types);
				else
					cboxs[i-5] = new JComboBox(options);
			}
			for (int i = 0; i < 3; i++)
				for (int j = 0; j < _rank; j++) {
					dimensions[i][j] = new JTextField();
					Dimensions[i][j] = new JLabel(String.valueOf(j));
				}
		}

		private void addBoxes() {
			int x = 10, y = 10;
			for (int i = 0; i < 9; i++) {
				jbuttons[i].setBounds(x, y, 150, 20);
				this.getContentPane().add(jbuttons[i]);
				if (i < 5) {
					fields[i].setBounds(x + 160, y, 100, 20);
					this.getContentPane().add(fields[i]);
				}
				else {
					cboxs[i-5].setBounds(x + 160, y, 100, 20);
					this.getContentPane().add(cboxs[i-5]);
				}
				y += 25;
			}
			y = addFilters(y);
			if (max_y < y)
				max_y = y;
		}

		private int addFilters(int y) {
			if (filter.length == 0)
				return y;
			filter_params = new JTextField[filter.length][];
			for (int i = 0; i < filter.length; i++) {
				y = addFilter(y, i) + 25;
			} 
			return y;
		}

		private int addFilter(int y, int i) {
			int x = 10;
			if (filter[i].equals("Shuffle")) {
				filter_params[i] = new JTextField[1];
				JLabel temp = new JLabel("Filter Type: Shuffle");
				temp.setBounds(x, y, 150, 20);
				this.getContentPane().add(temp);
				JButton btemp = new JButton("Flag");
				y += 25;
				btemp.setBounds(x+20, y, 100, 20);
				btemp.setActionCommand(String.valueOf(15));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				this.getContentPane().add(btemp);
				filter_params[i][0] = new JTextField();
				filter_params[i][0].setBounds(x+200, y, 60, 20);
				this.getContentPane().add(filter_params[i][0]);
			}
			else if (filter[i].equals("Fletcher")) {
				filter_params[i] = new JTextField[1];
				JLabel temp = new JLabel("Filter Type: Fletcher");
				temp.setBounds(x, y, 150, 20);
				this.getContentPane().add(temp);
				JButton btemp = new JButton("Flag");
				y += 25;
				btemp.setBounds(x+20, y, 100, 20);
				btemp.setActionCommand(String.valueOf(15));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				this.getContentPane().add(btemp);
				filter_params[i][0] = new JTextField();
				filter_params[i][0].setBounds(x+200, y, 60, 20);
				this.getContentPane().add(filter_params[i][0]);
			}
			else if (filter[i].equals("Gzip")) {
				JLabel temp = new JLabel("Filter Type: Gzip");
				temp.setBounds(x, y, 150, 20);
				this.getContentPane().add(temp);
				JButton btemp = new JButton("Compression Level");
				btemp.setBounds(x+20, y+50, 150, 20);
				btemp.setActionCommand(String.valueOf(16));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				this.getContentPane().add(btemp);
				filter_params[i] = new JTextField[2];
				filter_params[i][0] = new JTextField();
				filter_params[i][0].setBounds(x+200, y+50, 60, 20);
				this.getContentPane().add(filter_params[i][0]);
				btemp = new JButton("Flag");
				btemp.setBounds(x+20, y+25, 100, 20);
				btemp.setActionCommand(String.valueOf(15));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				this.getContentPane().add(btemp);
				filter_params[i][1] = new JTextField();
				filter_params[i][1].setBounds(x+200, y+25, 60, 20);
				this.getContentPane().add(filter_params[i][1]);
				y+=50;
			}
			else if (filter[i].equals("Szip")) {
				JLabel temp = new JLabel("Filter Type: Szip");
				temp.setBounds(x, y, 150, 20);
				this.getContentPane().add(temp);
				JButton btemp = new JButton("Flag");
				y += 25;
				filter_params[i] = new JTextField[3];
				btemp.setBounds(x+20, y, 150, 20);
				btemp.setActionCommand(String.valueOf(15));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				this.getContentPane().add(btemp);
				filter_params[i][0] = new JTextField();
				filter_params[i][0].setBounds(x+200, y, 60, 20);
				this.getContentPane().add(filter_params[i][0]);
				btemp = new JButton("Option Mask");
				btemp.setActionCommand(String.valueOf(17));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				y += 25;
				btemp.setBounds(x+20, y, 150, 20);
				this.getContentPane().add(btemp);
				options_mask.setBounds(x+200, y, 60, 20);
				this.getContentPane().add(options_mask);
				btemp = new JButton("Pixels/Block");
				btemp.setActionCommand(String.valueOf(18));
				btemp.addActionListener(new Frame2_gen_actionAdapter(this));
				y += 25;
				btemp.setBounds(x+20, y, 150, 20);
				this.getContentPane().add(btemp);
				filter_params[i][2] = new JTextField();
				filter_params[i][2].setBounds(x+200, y, 60, 20);
				this.getContentPane().add(filter_params[i][2]);
			}
			return y;
		}

		private void addDimensions() {
			int x = 350;
			int y = 10;
			for (int i = 0; i < 3; i++) {
				if (i == 1 && chunk.equals("No"))
					continue;
				if (i == 2 && extend.equals("No"))
					continue;
				JButton temp = new JButton(dims[i]);
				temp.setActionCommand(String.valueOf(i+9));
				temp.addActionListener(new Frame2_gen_actionAdapter(this));
				temp.setBounds(x, y, 180, 20);
				this.getContentPane().add(temp);
				y += 25;
				for (int j = 0; j < _rank; j++) {
					Dimensions[i][j].setBounds(x+25, y, 60, 20);
					this.getContentPane().add(Dimensions[i][j]);
					dimensions[i][j].setBounds(x+35, y, 60, 20);
					this.getContentPane().add(dimensions[i][j]);
					y += 25;
				}
			}
			JLabel flabel = new JLabel("File");
			flabel.setBounds(x, y, 100, 20);
			this.getContentPane().add(flabel);
			filels[1] = new JButton("Type");
			y += 25;
			filels[1].setActionCommand(String.valueOf(13));
			filels[1].addActionListener(new Frame2_gen_actionAdapter(this));
			filels[1].setBounds(x, y, 100, 20);
			this.getContentPane().add(filels[1]);
			ftype.setBounds(x+110, y, 100, 20);
			this.getContentPane().add(ftype);
			y += 25;
			filels[2] = new JButton("Name");
			filels[2].setActionCommand(String.valueOf(14));
			filels[2].addActionListener(new Frame2_gen_actionAdapter(this));
			filels[2].setBounds(x, y, 100, 20);
			this.getContentPane().add(filels[2]);
			f_name.setBounds(x+110, y, 60, 20);
			this.getContentPane().add(f_name);
			if (max_y < y)
				max_y = y;
		}

		private void jbInit() throws Exception {
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.getContentPane().setLayout(null);
			addBoxes();
			addDimensions();
			JButton gen = new JButton("Generate >");
			gen.setBounds(425, max_y + 50, 100, 20);
			gen.setActionCommand(String.valueOf(20));
			gen.addActionListener(new Frame2_gen_actionAdapter(this));
			this.getContentPane().add(gen);
			this.setSize(600, max_y + 125);
			this.setResizable(false);
		}

		private void outputData() {
			try {
				FileWriter writer = new FileWriter("params.xml");
				writer.write("<Params>\n");
				for (int i = 0; i < 9; i++) {
					if (i < 5)
						if (fields[i].getText().trim().equals(""))
							continue;
					if (i < 5)
						writer.write("\t<" + tags[i] + ">" + fields[i].getText() + "</" + tags[i] + ">\n");
					else
						writer.write("\t<" + tags[i] + ">" + (String) cboxs[i-5].getSelectedItem() + "</" + tags[i] + ">\n");
				}
				writer.write("\t<DataDims>\n");
				for (int i = 0; i < _rank; i++)
					writer.write("\t\t<" + i + ">" + dimensions[0][i].getText() + "</" + i + ">\n");
				writer.write("\t</DataDims>\n");
				if (chunk.equals("Yes")) {
					writer.write("\t<ChunkDims>\n");
					for (int i = 0; i < _rank; i++)
						writer.write("\t\t<" + i + ">" + dimensions[1][i].getText() +
								"</" + i + ">\n");
					writer.write("\t</ChunkDims>\n");
				}
				if (extend.equals("Yes")) {
					writer.write("\t<Extend>Yes</Extend>\n");
					writer.write("\t<EDataDims>\n");
					for (int i = 0; i < _rank; i++)
						writer.write("\t\t<" + i + ">" + dimensions[2][i].getText() +
								"</" + i + ">\n");
					writer.write("\t</EDataDims>\n");
				}
				if (filter.length != 0 ) {
					for (int j = 0; j < filter.length; j++) {
						if (filter[j].equals("Fletcher")) {
							writer.write("\t<Filter>\n\t\t<Type>" + filter[j] + "</Type>\n" +
									"\t\t<Flag>" + filter_params[j][0].getText() + "</Flag>\n" +
									"\t</Filter>\n");
						}
						else if (filter[j].equals("Shuffle")) {
							writer.write("\t<Filter>\n\t\t<Type>" + filter[j] + "</Type>\n" +
									 "\t\t<Flag>" + filter_params[j][0].getText() + "</Flag>\n" +
									 "\t</Filter>\n");
						}
						else if (filter[j].equals("Gzip")) {
							writer.write("\t<Filter>\n\t\t<Type>" + filter[j] + "</Type>\n" +
									"\t\t<Flag>" + filter_params[j][1].getText() + "</Flag>\n" +
									"\t\t<0>"+ filter_params[j][0].getText() +"</0>\n" + "\t</Filter>\n");
						}
						else if (filter[j].equals("Szip")) {
							String om = "";
							if (((String) options_mask.getSelectedItem()).equals("NN Coding"))
									{
										om = "1";
									}
							else {
								om = "0";
							}
							writer.write("\t<Filter>\n\t\t<Type>" + filter[j] + "</Type>\n\t\t<Flag>"
									+ filter_params[j][0].getText() + "</Flag>\n" + "\t\t<0>"+
									filter_params[j][1].getText() +"</0>\n\t\t<1>" +
									filter_params[j][2].getText() + "</1>\n\t</Filter>\n");
						}
					}
				}
				writer.write("\t<File>\n");
				writer.write("\t\t<Type>" + (String) ftype.getSelectedItem() + "</Type>\n");
				writer.write("\t\t<Name>" + f_name.getText() + "</Name>\n");
				writer.write("\t</File>\n");
				writer.write("</Params>\n");
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void gen_actionPerformed(ActionEvent e) {
			int i = Integer.parseInt(e.getActionCommand());
			if (i == 20) {
				outputData();
				JOptionPane.showMessageDialog(this, "Parameters written to params.xml"
						+ " file");
				System.exit(0);
			}
			else
				JOptionPane.showMessageDialog(this, String.valueOf(help[i]));

		}
}


class Frame2_gen_actionAdapter implements ActionListener {
	private Frame2 adaptee;
	Frame2_gen_actionAdapter(Frame2 adaptee) {
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e) {
		adaptee.gen_actionPerformed(e);
	}
}
