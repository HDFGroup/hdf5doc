import java.awt.BorderLayout;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JList;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FrameI extends JFrame {
    private JLabel[] labels;
		private JButton pos;
		private JButton next;
		private JTextField[] fields;
		private String rank, chunk, extend;
		private String[] filters;

    public FrameI(String rank, String[] filters, String chunk, String extend) {
			this.rank = rank;
			this.chunk = chunk;
			this.extend = extend;
			this.filters = filters;
        try {
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

		private void jbInit() throws Exception {
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.getContentPane().setLayout(null);
			labels = new JLabel[filters.length + 1];
			fields = new JTextField[filters.length];
			labels[0] = new JLabel("Filter Type");
			labels[0].setBounds(new Rectangle(20, 25, 100, 20));
			this.getContentPane().add(labels[0], null);
			pos = new JButton("Position");
			pos.setActionCommand(String.valueOf(0));
			pos.addActionListener(new FrameI_proceed_actionAdapter(this));
			pos.setBounds(new Rectangle(160, 25, 100, 20));
			this.getContentPane().add(pos, null);
			int y = 25;
			for (int i = 0; i < filters.length; i++) {
				y += 25;
				labels[i+1] = new JLabel(filters[i]);
				labels[i+1].setBounds(new Rectangle(20, y, 100, 20));
				this.getContentPane().add(labels[i+1], null);
				fields[i] = new JTextField();
				fields[i].setBounds(new Rectangle(160, y, 100, 20));
				this.getContentPane().add(fields[i], null);
			}
			y += 25;
			next = new JButton("Next>");
			next.setActionCommand(String.valueOf(1));
			next.addActionListener(new FrameI_proceed_actionAdapter(this));
			next.setBounds(new Rectangle(200, y, 100, 20));
			this.getContentPane().add(next, null);
			this.setSize(320, y + 50);
			this.setResizable(false);
			this.setVisible(true);
		}

		public void sort() {
			String[] temp = new String[filters.length];
			for (int i = 0; i < filters.length; i++) {
				String pos = fields[i].getText();
				temp[Integer.parseInt(pos)] = filters[i];
			}
			filters = temp;
		}
		
		public void proceed_actionPerformed(ActionEvent e) {
			int i = Integer.parseInt(e.getActionCommand());
			if (i == 0) {
						JOptionPane.showMessageDialog(this, "This is so that we can reorder"
								+ " the filters.\n To make a filter appear first in the\n"
								+ "pipeline "
								+ "make its position 0,\n and give positions to the various"
								+ "filters\n in the ascending order of their appearence in the"
								+ "\n pipeline. "); 
			} 
			else {
				sort();
				Frame2 f2 = new Frame2(rank, filters, chunk, extend);
				this.setVisible(false);
				f2.setVisible(true);
			} 
		} 
}


class FrameI_proceed_actionAdapter implements ActionListener {
    private FrameI adaptee;
    FrameI_proceed_actionAdapter(FrameI adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.proceed_actionPerformed(actionEvent);
    }
}
