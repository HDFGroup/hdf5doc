import java.awt.BorderLayout;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JList;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class HSTestWidget extends JFrame {
	private JTextField rank;
	private JButton Rank;
	private JButton Filter;
	private JList filter;
	private JButton Extend;
	private JButton Chunk;
	private JComboBox extend;
	private JComboBox chunk;
	private JButton proceed;
	private String[] filters = {"Fletcher", "Gzip", "Szip", "Shuffle"};
	private String[] extendo = {"Yes", "No"};
	private String[] chunko = {"Yes", "No"};
	private String[] help = {"Rank of the dataset.",
		"Determines which filter would be used",
		"Determines whether chunking would be used",
		"If extend is used then the tests would start with the predefined dimensions,\n do a read and then extend the dataset and do a read again\n"};

		public HSTestWidget() {
			try {
				jbInit();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}

		private void jbInit() throws Exception {
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			rank = new JTextField("2");
			Rank = new JButton("Rank");
			Rank.setActionCommand(String.valueOf(0));
			Rank.addActionListener(new HSTestWidget_proceed_actionAdapter(this));
			Filter = new JButton("Filter");
			Filter.setActionCommand(String.valueOf(1));
			Filter.addActionListener(new HSTestWidget_proceed_actionAdapter(this));
			Chunk = new JButton("Chunk");
			Chunk.setActionCommand(String.valueOf(2));
			Chunk.addActionListener(new HSTestWidget_proceed_actionAdapter(this));
			Extend = new JButton("Extend");
			Extend.setActionCommand(String.valueOf(3));
			Extend.addActionListener(new HSTestWidget_proceed_actionAdapter(this));
			proceed = new JButton("Proceed >");
			Rank.setBounds(new Rectangle(20, 25, 100, 20));
			filter = new JList(filters);
			extend = new JComboBox(extendo);
			chunk = new JComboBox(chunko);
			Filter.setBounds(new Rectangle(20, 60, 100, 20));
			this.getContentPane().setLayout(null);
			rank.setBounds(new Rectangle(200, 25, 100, 20));
			filter.setBounds(new Rectangle(200, 60, 100, 70));
			proceed.setBounds(new Rectangle(240, 240, 100, 20));
			proceed.setActionCommand(String.valueOf(4));
			proceed.addActionListener(new HSTestWidget_proceed_actionAdapter(this));
			chunk.setBounds(new Rectangle(200, 160, 100, 20));
			Chunk.setBounds(new Rectangle(20, 160, 100, 20));
			extend.setBounds(new Rectangle(200, 190, 100, 20));
			Extend.setBounds(new Rectangle(20, 190, 100, 20));
			this.getContentPane().add(rank, null);
			this.getContentPane().add(Filter, null);
			this.getContentPane().add(Rank, null);
			this.getContentPane().add(filter, null);
			this.getContentPane().add(Chunk, null);
			this.getContentPane().add(Extend, null);
			this.getContentPane().add(proceed, null);
			this.getContentPane().add(chunk, null);
			this.getContentPane().add(extend, null);
			this.setSize(390, 290);
			this.setResizable(false);
			this.setVisible(true);
		}

		public static void main(String[] args) {
			HSTestWidget frame1 = new HSTestWidget();
		}

		public void proceed_actionPerformed(ActionEvent e) {
			Frame2 f2 = null;
			int i = Integer.parseInt(e.getActionCommand());
			if (i == 4) {
				this.setVisible(false);
				Object[] vals = filter.getSelectedValues();
				String[] filters = new String[vals.length];
				for (int j = 0; j < vals.length; j++)
					filters[j] = (String) vals[j];
				if (vals.length == 0)  {
					if (((String) extend.getSelectedItem()).equals("Yes") &&
							((String) chunk.getSelectedItem()).equals("No")) {
						JOptionPane.showMessageDialog(this, "Extensibility is chosen hence chunking has been endabled.");
						f2 = new Frame2(rank.getText(), filters, "Yes", (String) extend.getSelectedItem());
					}
					else {
						f2 = new Frame2(rank.getText(), filters, (String) chunk.getSelectedItem(), (String) extend.getSelectedItem());
					}
						f2.setVisible(true);
				}
				else if (vals.length == 1) {
					if (((String) chunk.getSelectedItem()).equals("No")) {
						JOptionPane.showMessageDialog(this, "A Filter is chosen hence chunking has been endabled.");
						f2 = new Frame2(rank.getText(), filters, "Yes", (String) extend.getSelectedItem());
						f2.setVisible(true);
					}
					else {
						f2 = new Frame2(rank.getText(), filters, (String) chunk.getSelectedItem(), (String) extend.getSelectedItem());
						f2.setVisible(true);
					}
				}
				else {
					if (((String) chunk.getSelectedItem()).equals("No")) {
						JOptionPane.showMessageDialog(this, "A Filter is chosen hence chunking has been endabled.");
						Frame fi = new FrameI(rank.getText(), filters, "Yes", (String) extend.getSelectedItem());
						this.setVisible(false);
						fi.setVisible(true);
					}
					else {
						FrameI fi = new FrameI(rank.getText(), filters, (String) chunk.getSelectedItem(), (String) extend.getSelectedItem());
						fi.setVisible(true);
					}
				}
			}
			else {
				JOptionPane.showMessageDialog(this, help[i]);
			}
		}
}


class HSTestWidget_proceed_actionAdapter implements ActionListener {
	private HSTestWidget adaptee;
	HSTestWidget_proceed_actionAdapter(HSTestWidget adaptee) {
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent actionEvent) {
		adaptee.proceed_actionPerformed(actionEvent);
	}
}
