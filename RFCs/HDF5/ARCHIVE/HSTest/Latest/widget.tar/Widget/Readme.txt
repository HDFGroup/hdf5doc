
Files
Source:
  Frame2.java
  HSTestWidget.java
Manifest file (for the jar)
  manif

Makefile

To build:
  make


To run:
  java -jar widget.jar


Note the hstool can be obtained from CVS:
 cvs checkout h5_hstest
